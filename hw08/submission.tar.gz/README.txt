Game Name: Catch The Stars

How to Play
-your score is the number of stars you catch before reaching the goal zone
-to catch a star, you should move the sprite near a star, and then press enter
-to win the game, your sprite needs to hover over the goal zone when your score is 10
-if your score is less than 10 when your sprite reaches the goal zone, you lose
-the goal zone is the green rectangle on the bottom right hand side of the screen
Good luck!

Extra Credit 1
-the sprite star is being animated on the title screen, the win screen, and the lose screen
-the sprite being animated on the title screen is the same sprite used for playing the game
-the only difference in the sprite on the title screen and the one playing the game is the
color, since the user chooses which color the sprite playing the game is, while the sprite
being animated on the title screen is magenta in every scenario

Extra Credit 2
-the additional screen is the 'Color Options' screen
-it asks the user what color they would like their sprite to be
-depending on what key the user presses, their sprite will be a different color
-the colors and their respective keys are:
    Magenta: Up
    Cyan: Right
    White: Down
    Red: Left

Required Images
-the first full screen image is the one I used for the title screen
-the second full screen image is the one I used for the 'How To Play' screen
-I also used full screen images for the win and lose screens
-the required image that is less than the full screen is the one I used for displaying the score

Text for Progression:
-I used a score counter to display progression in the game
-although the word "Score:" and the background are displayed by an image, the text showing the score is
text drawn to the screen using the drawChar function

I hope you enjoy playing!