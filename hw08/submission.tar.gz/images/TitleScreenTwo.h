/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 TitleScreenTwo TitleScreenTwo.png 
 * Time-stamp: Monday 04/03/2023, 00:49:43
 * 
 * Image Information
 * -----------------
 * TitleScreenTwo.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TITLESCREENTWO_H
#define TITLESCREENTWO_H

extern const unsigned short TitleScreenTwo[38400];
#define TITLESCREENTWO_SIZE 76800
#define TITLESCREENTWO_LENGTH 38400
#define TITLESCREENTWO_WIDTH 240
#define TITLESCREENTWO_HEIGHT 160

#endif

