/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 TitleScreenSix TitleScreenSix.png 
 * Time-stamp: Monday 04/03/2023, 00:50:20
 * 
 * Image Information
 * -----------------
 * TitleScreenSix.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TITLESCREENSIX_H
#define TITLESCREENSIX_H

extern const unsigned short TitleScreenSix[38400];
#define TITLESCREENSIX_SIZE 76800
#define TITLESCREENSIX_LENGTH 38400
#define TITLESCREENSIX_WIDTH 240
#define TITLESCREENSIX_HEIGHT 160

#endif

