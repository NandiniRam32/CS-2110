/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 Options Options.png 
 * Time-stamp: Monday 04/03/2023, 02:00:22
 * 
 * Image Information
 * -----------------
 * Options.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef OPTIONS_H
#define OPTIONS_H

extern const unsigned short Options[38400];
#define OPTIONS_SIZE 76800
#define OPTIONS_LENGTH 38400
#define OPTIONS_WIDTH 240
#define OPTIONS_HEIGHT 160

#endif

