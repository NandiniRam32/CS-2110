/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=30x10 TimeLeft TimeLeft.png 
 * Time-stamp: Sunday 04/02/2023, 19:15:34
 * 
 * Image Information
 * -----------------
 * TimeLeft.png 30@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TIMELEFT_H
#define TIMELEFT_H

extern const unsigned short TimeLeft[300];
#define TIMELEFT_SIZE 600
#define TIMELEFT_LENGTH 300
#define TIMELEFT_WIDTH 30
#define TIMELEFT_HEIGHT 10

#endif

