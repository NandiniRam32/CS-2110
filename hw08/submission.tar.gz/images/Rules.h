/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 Rules Rules.png 
 * Time-stamp: Monday 04/03/2023, 00:40:34
 * 
 * Image Information
 * -----------------
 * Rules.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef RULES_H
#define RULES_H

extern const unsigned short Rules[38400];
#define RULES_SIZE 76800
#define RULES_LENGTH 38400
#define RULES_WIDTH 240
#define RULES_HEIGHT 160

#endif

