/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=50x37 Timer Timer.png 
 * Time-stamp: Sunday 04/02/2023, 17:16:26
 * 
 * Image Information
 * -----------------
 * Timer.png 50@37
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TIMER_H
#define TIMER_H

extern const unsigned short Timer[1850];
#define TIMER_SIZE 3700
#define TIMER_LENGTH 1850
#define TIMER_WIDTH 50
#define TIMER_HEIGHT 37

#endif

