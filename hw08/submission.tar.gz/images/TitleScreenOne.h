/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 TitleScreenOne TitleScreenOne.png 
 * Time-stamp: Monday 04/03/2023, 00:49:35
 * 
 * Image Information
 * -----------------
 * TitleScreenOne.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TITLESCREENONE_H
#define TITLESCREENONE_H

extern const unsigned short TitleScreenOne[38400];
#define TITLESCREENONE_SIZE 76800
#define TITLESCREENONE_LENGTH 38400
#define TITLESCREENONE_WIDTH 240
#define TITLESCREENONE_HEIGHT 160

#endif

