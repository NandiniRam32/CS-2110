/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 EnterToStart EnterToStart.png 
 * Time-stamp: Saturday 04/01/2023, 21:10:05
 * 
 * Image Information
 * -----------------
 * EnterToStart.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ENTERTOSTART_H
#define ENTERTOSTART_H

extern const unsigned short EnterToStart[38400];
#define ENTERTOSTART_SIZE 76800
#define ENTERTOSTART_LENGTH 38400
#define ENTERTOSTART_WIDTH 240
#define ENTERTOSTART_HEIGHT 160

#endif

