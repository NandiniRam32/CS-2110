/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 TitleScreenTen TitleScreenTen.png 
 * Time-stamp: Sunday 04/02/2023, 01:53:43
 * 
 * Image Information
 * -----------------
 * TitleScreenTen.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TITLESCREENTEN_H
#define TITLESCREENTEN_H

extern const unsigned short TitleScreenTen[38400];
#define TITLESCREENTEN_SIZE 76800
#define TITLESCREENTEN_LENGTH 38400
#define TITLESCREENTEN_WIDTH 240
#define TITLESCREENTEN_HEIGHT 160

#endif

