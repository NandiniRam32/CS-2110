/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 TitleScreenSeven TitleScreenSeven.png 
 * Time-stamp: Monday 04/03/2023, 00:50:27
 * 
 * Image Information
 * -----------------
 * TitleScreenSeven.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TITLESCREENSEVEN_H
#define TITLESCREENSEVEN_H

extern const unsigned short TitleScreenSeven[38400];
#define TITLESCREENSEVEN_SIZE 76800
#define TITLESCREENSEVEN_LENGTH 38400
#define TITLESCREENSEVEN_WIDTH 240
#define TITLESCREENSEVEN_HEIGHT 160

#endif

