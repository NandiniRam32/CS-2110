/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 TitleScreenZero TitleScreenZero.png 
 * Time-stamp: Monday 04/03/2023, 00:49:26
 * 
 * Image Information
 * -----------------
 * TitleScreenZero.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TITLESCREENZERO_H
#define TITLESCREENZERO_H

extern const unsigned short TitleScreenZero[38400];
#define TITLESCREENZERO_SIZE 76800
#define TITLESCREENZERO_LENGTH 38400
#define TITLESCREENZERO_WIDTH 240
#define TITLESCREENZERO_HEIGHT 160

#endif

