/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=56x16 Score Score.png 
 * Time-stamp: Tuesday 04/04/2023, 14:35:17
 * 
 * Image Information
 * -----------------
 * Score.png 56@16
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SCORE_H
#define SCORE_H

extern const unsigned short Score[896];
#define SCORE_SIZE 1792
#define SCORE_LENGTH 896
#define SCORE_WIDTH 56
#define SCORE_HEIGHT 16

#endif

