/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 TitleScreenFour TitleScreenFour.png 
 * Time-stamp: Monday 04/03/2023, 00:50:00
 * 
 * Image Information
 * -----------------
 * TitleScreenFour.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TITLESCREENFOUR_H
#define TITLESCREENFOUR_H

extern const unsigned short TitleScreenFour[38400];
#define TITLESCREENFOUR_SIZE 76800
#define TITLESCREENFOUR_LENGTH 38400
#define TITLESCREENFOUR_WIDTH 240
#define TITLESCREENFOUR_HEIGHT 160

#endif

