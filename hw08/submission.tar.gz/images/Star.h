/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=50x37 Star Star.png 
 * Time-stamp: Saturday 04/01/2023, 22:35:25
 * 
 * Image Information
 * -----------------
 * Star.png 50@37
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef STAR_H
#define STAR_H

extern const unsigned short Star[1850];
#define STAR_SIZE 3700
#define STAR_LENGTH 1850
#define STAR_WIDTH 50
#define STAR_HEIGHT 37

#endif

