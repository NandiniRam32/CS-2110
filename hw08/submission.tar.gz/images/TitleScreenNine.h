/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 TitleScreenNine TitleScreenNine.png 
 * Time-stamp: Monday 04/03/2023, 00:50:45
 * 
 * Image Information
 * -----------------
 * TitleScreenNine.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TITLESCREENNINE_H
#define TITLESCREENNINE_H

extern const unsigned short TitleScreenNine[38400];
#define TITLESCREENNINE_SIZE 76800
#define TITLESCREENNINE_LENGTH 38400
#define TITLESCREENNINE_WIDTH 240
#define TITLESCREENNINE_HEIGHT 160

#endif

