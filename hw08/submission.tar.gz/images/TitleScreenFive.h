/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 TitleScreenFive TitleScreenFive.png 
 * Time-stamp: Monday 04/03/2023, 00:50:08
 * 
 * Image Information
 * -----------------
 * TitleScreenFive.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TITLESCREENFIVE_H
#define TITLESCREENFIVE_H

extern const unsigned short TitleScreenFive[38400];
#define TITLESCREENFIVE_SIZE 76800
#define TITLESCREENFIVE_LENGTH 38400
#define TITLESCREENFIVE_WIDTH 240
#define TITLESCREENFIVE_HEIGHT 160

#endif

