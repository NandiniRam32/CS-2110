/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 TitleScreenEight TitleScreenEight.png 
 * Time-stamp: Monday 04/03/2023, 00:50:36
 * 
 * Image Information
 * -----------------
 * TitleScreenEight.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TITLESCREENEIGHT_H
#define TITLESCREENEIGHT_H

extern const unsigned short TitleScreenEight[38400];
#define TITLESCREENEIGHT_SIZE 76800
#define TITLESCREENEIGHT_LENGTH 38400
#define TITLESCREENEIGHT_WIDTH 240
#define TITLESCREENEIGHT_HEIGHT 160

#endif

